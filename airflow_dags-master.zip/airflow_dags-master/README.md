# airflow_dags
dags for airflow actioins

### install_onvms
for running this dag we need to create variable under admin>Variables>create

  key: install_on_vm

  value : { "vm" : [{ "hostname":"192.168.60.16", "username":"root", "password":"Welcome@1", "port":"22" }, { "hostname":"192.168.60.15", "username":"root", "password":"Welcome@1", "port":"22" }], "packages":["nano","zip"] } 
