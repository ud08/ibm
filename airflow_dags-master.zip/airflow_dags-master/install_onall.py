from airflow import DAG
import json
from airflow.operators.bash_operator import BashOperator
from airflow.models import Variable
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2001, 6, 1),
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'schedule_interval': '@once',
}

release_ip = Variable.get("release_ip",deserialize_json = True)
ips = release_ip["ips"]
result = "' - '".replace('-', ",".join('"{}"'.format(i) for i in ips))
result = result[2:-2]


dag = DAG(
    'install_onvms', default_args=default_args, schedule_interval='@once')
 
install_on_vm = Variable.get("install_on_vm",deserialize_json = True)
vms = install_on_vm["vm"]
packages = install_on_vm["packages"]

pkg = "' - '".replace('-', ",".join('"{}"'.format(i) for i in packages))
pkg = pkg[2:-2]

vm = ''
for i in vms:
    vm += ','+json.dumps(i)
vm = vm[1:]

print(vm)
print(pkg)

t1 = BashOperator(
    task_id='install_onvms',
    # string = 'curl --header "Authorization: Basic MjNiYzQ2YjEtNzFmNi00ZWQ1LThjNTQtODE2YWE0ZjhjNTAyOjEyM3pPM3haQ0xyTU42djJCS0sxZFhZRnBYbFBrY2NPRnFtMTJDZEFzTWdSVTRWck5aOWx5R1ZDR3VNREdJd1A=" -X GET https://192.168.60.12:31001/api/v1/namespaces/_/activations/e3278f05b514812b278f05b51a81299 --insecure'
    bash_command = '''curl --header "Authorization: Basic MjNiYzQ2YjEtNzFmNi00ZWQ1LThjNTQtODE2YWE0ZjhjNTAyOjEyM3pPM3haQ0xyTU42djJCS0sxZFhZRnBYbFBrY2NPRnFtMTJDZEFzTWdSVTRWck5aOWx5R1ZDR3VNREdJd1A=" -d '{ "vm" : ['''+vm+'''], "packages":['''+pkg+'''] }' -H "Content-Type: application/json" -X POST https://192.168.60.12:31001/api/v1/namespaces/_/actions/installonvms --insecure''',dag=dag)