# django_alt
alternative backup approach
