import os
import json
import paramiko
import warnings

warnings.filterwarnings(action='ignore', module='.*paramiko.*')
ssh = paramiko.SSHClient()  #create an ssh client

file = os.path.dirname(os.path.realpath(__file__))
file = f"{file}\input.json"

command = 'hostname'

def mkdir(file):
   with open(file) as json_file:
       data = json.load(json_file)
       for item in data["data"]:
           username = item["username"]
           password = item["password"]
           target = item["system"]
           ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy()) #auto accept ssh key
           ssh.connect(target, port=22, username=username, password=password)  #connect to the target
           stdin, stdout, stderr = ssh.exec_command(command) #execute the command
           output = stdout.readlines() #get the output
           outstore = '\n'.join(output) #format the output to print each line in a new line
           print(outstore) #print outstore


while True:
   if file:
       mkdir(file)