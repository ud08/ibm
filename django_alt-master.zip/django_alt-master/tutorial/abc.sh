while [ ! -e json.txt ] ;
do
sleep 1
done
echo "ok"
python upper.py
ls
sleep 3s