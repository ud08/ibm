from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from snippets.models import Snippet
import json
import os
import subprocess
from snippets.serializers import SnippetSerializer

@csrf_exempt
def snippet_list(request):
    """
    List all code snippets, or create a new snippet.
    """
    if request.method == 'GET':
        snippets = Snippet.objects.all()
        serializer = SnippetSerializer(snippets, many=True)
        return JsonResponse(serializer.data, safe=False)

    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = SnippetSerializer(data=data)   
        if serializer.is_valid():
            # serializer.save()
            with open('json_data.txt', 'w') as outfile: 
                json.dump(serializer.data, outfile)
            os.system("docker build -f ./img.dockerfile . -t image1")
            id = str(subprocess.check_output("docker run -d -it image1",shell=True))
            id=str(id[2:-3])
            os.system("docker cp "+id+":output.txt json_data.txt")
            with open('json_data.txt') as f:
                data = json.load(f)
            print(data)
            serializer = SnippetSerializer(data=data)
            if serializer.is_valid():
                serializer.save()
            os.system("docker stop "+id)
            os.system("docker rm "+id)
            os.system("docker rmi image1")
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)
    
    elif request.method == 'DELETE':
        snippets = Snippet.objects.all()
        snippets.delete()
        return Response(status=status.HTTP_204_NO_CONTENT) 
# id = "dc6613c9ab7aff66f9cf9afbe2e03f87f7eaca9cb8c75afc3bc9539354dcb85a"
            # os.system("docker cp json_data.txt "+id+":json.txt")
            # os.system("docker exec -it "+ id + " sh")
            # subprocess.call("ls -la")
            # exec("ls")
            #os.system("docker cp json_data.txt "+id+":input.txt")
            # os.system("docker cp "+id+":input.txt sid.txt")
def snippet_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        snippet = Snippet.objects.get(pk=pk)
    except Snippet.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = SnippetSerializer(snippet)
        return JsonResponse(serializer.data)

    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = SnippetSerializer(snippet, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        snippet.delete()
        return HttpResponse(status=204)
# Create your views here.
