import json
dict={}
with open('json_data.txt') as handle:
    dict = json.loads(handle.read())
for item in dict:
    dict[item]=(str(dict[item]).upper())
print(dict)

with open('output.txt','w') as fp:
    json.dump(dict,fp)
#f=open("output.txt", "r")
#contents =f.read()
#print(contents)