import os
import sys
import json
from pathlib import Path

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(BASE_DIR, 'input')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')

'''Start of Runners'''

def uppercase(data):
   '''takes a non nested dictionary and converts the values to uppercase'''
   output = {}
   for k, v in data.items():
       output[k] = v.upper()
   return output

'''End of Runners'''

dispatcher = {
   # register your functions here
   'uppercase': uppercase
}

def runner(input_jsonfile):
   '''parses a json file, runs the function mentioned in that json file
   by passing the data in that jsonfile as an argument to hte function'''
   with open(input_jsonfile, 'r') as f:
       datastore = json.load(f)
   function = datastore['function']
   runtime = datastore['runtime']
   data = datastore['data']
   return dispatcher[function](data)

def get_input_files():
   files = [x for x in os.listdir(INPUT_DIR) if x.endswith('.json')]
   input_files = [os.path.join(INPUT_DIR, file) for file in files]
   return input_files

def write_output(a):
   files = [x for x in os.listdir(INPUT_DIR) if x.endswith('.json')]
   if(len(files)<1):
      return
   input_files = [os.path.join(INPUT_DIR, file) for file in files]
   with open(input_files[0]) as handle:
      dict = json.loads(handle.read())
   os.remove(input_files[0])
   dict.pop('data')
   dict.update({"data":a})
   dict.update({"logs":""})
   # print(dict)
   output_file = files[0][:-5] +"_output.json"
   # print(output_file)
   f = open(os.path.join(OUTPUT_DIR, output_file), 'w')
   json.dump(dict,f)

def looper():
   for input_jsonfile in get_input_files():
       return runner(input_jsonfile)

while(True):
   a = looper()
   write_output(a)