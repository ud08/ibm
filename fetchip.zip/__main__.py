import requests
def main(params):
    dict = {}
    r = requests.get("http://192.168.60.12:32660/api/ipam/prefixes")
    dict = r.json()
    list = []
    for id in dict["results"]:
        list.append(id['id'])
    # print(list)
    avail_ips= []
    for prefixid in list:
        ip = requests.get("http://192.168.60.12:32660/api/ipam/prefixes/"+str(prefixid)+"/available-ips/",auth=('admin','admin'))
        avail_ips.append(ip.json()[0]['address'])
        data = {"address":ip.json()[0]['address'], "status":1}
        # print(type(data))
        url = "http://192.168.60.12:32660/api/ipam/ip-addresses/"
        headers = {"Authorization":"Token 0123456789abcdef0123456789abcdef01234567  "}
        r = requests.post(url,headers=headers,data=data)
        # print(r.json())
        # r = requests.post("http://192.168.60.12:32660/api/ipam/ip-addresses/",data=data,auth=('admin','admin'))
        # print(r.text)
    dic = {"Available IPs":avail_ips}
    return dic


